package lista_encadeada_avaliacao;

public class NoListaProva {
	private String info;
	private NoListaProva prox;
	
	public NoListaProva() {
		this.info = "";
		this.prox = null;
	}
	public NoListaProva(String info) {
		this.info = info;
		this.prox = null;
	}
	@Override
	public String toString() {
		return  info +  " ";
	}
	@Override
	public boolean equals(Object obj) {
		NoListaProva aux = (NoListaProva) obj;
		if (this.getInfo() == aux.getInfo()){
			return true;
		}
		return false;
	}
	
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public NoListaProva getProx() {
		return prox;
	}
	public void setProx(NoListaProva prox) {
		this.prox = prox;
	}
	
}


