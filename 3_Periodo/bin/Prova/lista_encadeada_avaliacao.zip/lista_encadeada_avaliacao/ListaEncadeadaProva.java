package lista_encadeada_avaliacao;

public class ListaEncadeadaProva {
	NoListaProva lista;
	int tamanho;

	public ListaEncadeadaProva() {
		this.lista = null;
		this.tamanho = 0;
	}
	
	public boolean adicionaInicio(String elemento) {
		NoListaProva novoNo = new NoListaProva(elemento);
		novoNo.setProx(this.lista);
		this.lista = novoNo;
		this.tamanho++;
		return true;
	}
	public boolean adiciona(String elemento) { 
		
		if (this.lista == null) {
			adicionaInicio(elemento);
			return true;
		}
		
		NoListaProva novoNo = new NoListaProva(elemento);
		NoListaProva p = this.lista;
		while ((p.getProx() != null)) {
			p = p.getProx();
		}
		p.setProx(novoNo);
		this.tamanho++;
		return true;
	}
	
	public void remove(int posicao) {
		if (this.tamanho == 0) return; 
		if (posicao < 0 || posicao >= this.tamanho) return; 
		NoListaProva p = this.lista; 
		NoListaProva ant = null;
		int pos = 0;
		while (pos < posicao) {
			ant = p;
			p = p.getProx();
			pos++;
		}
		
		if (ant == null) { 
			this.lista = this.lista.getProx();
		} else {
			ant.setProx(p.getProx());
		}
		this.tamanho--;
	}
	public int busca(String elemento) {
		if (this.tamanho == 0) return -1; //lista vazia
		NoListaProva p = this.lista; //p aponta para o in�cio da lista
		int pos = 0;
		while ( p!=null ) {
			if (p.getInfo().equals(elemento)) return pos-1;
			
			pos++;
			p = p.getProx();
		}
		remove(pos);
		return -1;
	}
	
	
	public String toString() {
		String str = "";
		NoListaProva p = this.lista;
		while (p != null) {
			str = str + " " + p.getInfo();
			p = p.getProx();
		}
		return str;
	}


}
