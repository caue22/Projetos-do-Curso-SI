package lista_encadeada_avaliacao;

public class TesteListaEncadeadaProva {
	public static void main(String[] args) {
		System.out.println("In�cio do Programa");
		ListaEncadeadaProva l1 = new ListaEncadeadaProva();
		l1.adiciona("Maria");
		l1.adiciona("Juca");
		l1.adiciona("Teo");
		l1.adiciona("Z�");
		//l1.adiciona(2, "2.5");
		//l1.remove(100);
		System.out.println(l1);
		System.out.println(l1.busca("Maria"));
		System.out.println(l1);
		System.out.println("Fim do Programa");
	}

}


