package lista_vetor_avaliacao;

public class TesteVetorProva {
	public static void main(String[] Args) {
		VetorProva v1 = new VetorProva();
		v1.adiciona("Caue");
		v1.adiciona("Joao");
		v1.adiciona("JOse");
		v1.adiciona("Biu");
		v1.remove("Joao");
		System.out.println(v1);
}
}
