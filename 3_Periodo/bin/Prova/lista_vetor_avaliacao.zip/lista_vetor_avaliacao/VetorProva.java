package lista_vetor_avaliacao;

public class VetorProva {
	private String[] elementos;
	private int tamanho;
	

	
	public VetorProva() { 
		elementos = new String[50];
		tamanho = 0;

	}
	
	public boolean adiciona(String elemento) {
		if (tamanho < elemento.length()) {
			elementos[tamanho] = elemento;
			tamanho++;
			return true;
		} else {
			return false;
		}
	}
	public void remove(String elemento) {
			for(int i=0; i<tamanho; i++) {
				if (elementos[i].equals(elemento)) {
					elementos[i] = elementos [i+1];
					return ;
				}
			}
			
		tamanho --;
		}
	
	
	
	
	public String toString() {

		String str = "";
		for (int i = 0; i < tamanho; i++) {
			str = str + elementos[i] + " ";

		}
		return str;

	}


}
